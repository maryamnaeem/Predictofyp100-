<template>
  <div class="h-100 p-4">
        <div class="d-flex pb-2 justify-content-end align-items-center">
            <div class="p-2">
                <select style="width:250px" class="custom-select text-md bg-light bd-none pl-4 pr-4 bd-round box-shadow" v-model="course">
                    <option selected>Specify Course</option>
                    <option value="Computer Science">Computer Science</option>
                    <option value="Pakistan Studies">Pakistan Studies</option>
                </select>
            </div>
            <div class="p-2">
                <select style="width:250px" class="custom-select text-md bg-light bd-none pl-4 pr-4 bd-round box-shadow" v-model="class_">
                    <option selected>Specify Class</option>
                    <option value="9">9th Class</option>
                    <option value="10">10th Class</option>
                    <option value="11">1st Year</option>
                    <option value="12">2nd Year</option>
                </select>                                  
            </div>
        </div>      
      <div v-if="course && class_ && course != 'Specify Course' && class_ != 'Specify Class' && past_papers.length == 0" class="w-100 justify-content-center align-items-center bd-bottom pb-5 flex-wrap d-flex animate__animated  animate__zoomIn animate__faster">
          <button class="btn btn-block d-flex align-items-center" style="font-size:5rem" @click="generatePaper()">
              <span class="mdi mdi-hexagon-multiple-outline text-orange mr-3"></span>
              <a href="javascript:void(0)" class="text-md text-dark">
                  <span v-if="!loading">Generate Paper (click)</span>
                  <span v-else>Generating...</span>
              </a>
          </button>
      </div>
     

      <div>
          <div>
              <div class="p-5" v-if="past_papers.length == 0">
                <h4 class="pb-2">Info</h4>
                <ul class="text-sm">
                    <li>First try to select the specefic class and course type</li>
                    <li>Once you select the specefic class and course, we will look up if the book is available or not.
                    </li>
                    <li>If the book is available for the current selection, we will generate past paper and will also generate a report.</li>
                </ul>
              </div>
              <div v-else class="mt-5 bd-bottom">
                  <div class="w-100" v-if="!view_report">
                        <div class="w-100 bd-bottom">
                            <div class="w-100 text-right">
                                <button class="btn bg-light" @click="view_report = true">
                                    <span class="d-flex align-items-center">
                                        <span class="mdi mdi-chart-timeline-variant text-orange mdi-24px"></span>
                                        <span class="ml-2"> Show Report</span>
                                    </span>
                                </button>
                            </div>
                            <button @click="tab = (i)" class="btn pl-3 pr-3 bd-radius-0 transition" :class="(i)==tab ? 'bg-orange text-white box-shadow text-md' : 'hov'" v-for="(paper, i) in past_papers" :key="i"> Paper {{ (i+1) }}</button>
                        </div>
                        <div class="w-100">
                            <div v-for="(section, k) in 2" :key="k" class="p-4 mt-5">
                                <h2 class="font-weight-bold">Section {{sections[k]}}</h2>
                                <div class="ml-4">
                                    <div>
                                        <div class="row small pb-1 mb-1 bd-bottom align-items-center" v-for="(q, i) in past_papers[tab][paperSections[k]]" :key="i">
                                            <p v-if="q.title" class="col-md-8 text-capitalize text-md">
                                                <span class="font-weight-bold">{{ i+1 }}. &nbsp;</span> {{formatTitle(q.title)}} <i class="font-weight-bold small text-orange">({{q.weight}})</i>
                                                <span v-if="q.parts" class="mt-2">
                                                    <p class="w-100 pt-1 mb-1 pl-4 small" v-for="(part, j) in q.list" :key="j">
                                                        {{part.title}} <i class="font-weight-bold small text-orange">({{part.weight}})</i>
                                                    </p>
                                                </span>
                                            </p>
                                            <div v-if="q.title" class="col-md-4 d-flex justify-content-center">
                                                <div class="c100 small" 
                                                    :class="['p' + Math.round(q.propability*100), 
                                                        q.propability > 0.75 ? 'green' : '', 
                                                        q.propability > 0 && q.propability < 0.25 ? 'orange' : '']">
                                                    <span>{{Math.round(q.propability*100)}}%</span>
                                                    <div class="slice">
                                                        <div class="bar"></div>
                                                        <div class="fill"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                  </div>
                  <div v-else>
                        <button @click="view_report=false" class="mdi mdi-chevron-left mdi-36px hov"></button>
                        <caption>Prioritization of Chapters in the form of Pie Chart</caption>
                        <h1 class="w-100 text-center mt-4 mb-4 text-capitalize font-weight-normal">

                        </h1>
                        <figure class="pie-chart w-100" :style="{background: gradient}">
                            <figcaption>
                                <p class="mb-0 pb-0 text-capitalize" v-for="(data, i) in pie_chart_data" :key="i">
                                    <a @click="activeChapterData = data.chapterNumber" href="javascript:void(0)" class="transition" :class="data.chapterNumber == activeChapterData ? 'font-weight-bold text-md text-orange' : 'text-dark '">
                                        {{data.chapter }}
                                        <strong class="small font-weight-bold">({{data.percent}})</strong>
                                    </a>
                                    <span :style="{color: data.color}"></span>                                                            
                                </p>
                            </figcaption>
                        </figure>        
                        <div class="w-100 text-center d-flex justify-content-center mt-5 mb-5 pb-5">
                            <table class="graph">
                                <caption>Prioritization of topics in the form of Bar Graph</caption>
                                <thead>
                                    <tr>
                                        <th scope="col">Item</th>
                                        <th scope="col">Percent</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="small animate__animated animate__zoomIn animate__faster" v-for="(topic, i) in topics.filter( el => el.chapter == activeChapterData)" :key="i" :style="{height: (topic.propability*100) + '%'}" style="max-width:50px">
                                        <th scope="row" class="text-capitalize small animate__animated animate__zoomIn animate__faster" >
                                            {{topic.name.replace(/[0-9]./g, '').substring(0, 50).trim()}} 
                                            <!-- - <span class="font-weight-bold">Ch #  ({{ topic.chapter}})</span> -->
                                            
                                            </th>
                                        <td :title="topic.name.replace(/[0-9]./g, '')"><span>{{Math.round(topic.propability*100)}}%</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script src="https://mozilla.github.io/pdf.js/build/pdf.js"></script>
<script>
import $ from 'jquery'
import PDFJS from 'pdfjs-dist'
import Tesseract from 'tesseract.js';

export default {
    data() {
        return {
            activeChapterData: 0,
            colors: ['#4e79a7', '#f28e2c', '#e15759', '#76b7b2', '#00876c', '#3d996f', '#64ab71', '#89bd73', '#afcd78', '#d6dd7f', '#ffeb8a', '#fdd072', '#fab460', '#f59855', '#ed7b4f', '#e25d4f', '#d43d51'],
            view_report: false,
            gradient: null,
            pie_chart_data: [],
            tab: 0,
            paperSections: ["A", "B"],
            sections: ["B", "C"],
            classes: [9, 10, 11, 12],
            loading: false,
            course: "Specify Course",
            class_: "Specify Class",
            chapters: [],
            topics: [], subtopics: [],
            past_papers: []
        }
    },
    methods: {
        formatTitle(title) {
            title = title.trim().split(" ")           

            if(/\d/.test(title[0])) {
                title.splice(0, 1)
            }

            return title.join(" ")
        },
        contains(item, items) {
            for(let i=0; i<items.length; i++) {
                if(items[i].name == item) {
                    return i;
                }
            }
            return -1;
        },
        findChapterOfTopic(topic, book) {
            for(let i=0; i<book.chapters.length; i++) {
                let chapter = book.chapters[i]
                for(let j=0; j< chapter.topics.length; j++) {
                    let t = chapter.topics[j].name
                    if(topic == t) {
                        return chapter.chapter                    
                    }
                }
            }
            return -1
        },
        generateReport({ dataset, book }) {
            console.log(book, 'my book')

            let sections = {
                A: [],
                B: []
            }
            for(let i=0; i<dataset.length; i++) {
                for(let j=0; j<dataset[i].sections[0].length; j++) {
                    let question = dataset[i].sections[0][j]
                    question.title ? sections.A.push(question) : ''
                }
                for(let j=0; j<dataset[i].sections[1].length; j++) {
                    let question = dataset[i].sections[1][j]
                    question.title ? sections.B.push(question) : ''
                }
            }
            let section = ['A', 'B']
            for(let y=0; y<2; y++) {
                let x = section[y]
                for(let i=0; i<sections[x].length; i++) {
                    let question = sections[x][i],
                        full_title = question.title
                    if(question.parts) {
                        for(let j=0; j<question.list.length; j++) {
                            full_title += " " + question.list[j].title
                        }
                    }
                    let { topics, subtopics, chapters, propability } = this.relateThisQ({ q:full_title.split(" "), chapters: book.chapters } )
                    sections[x][i]['propability'] = propability
                    for(let k=0; k<chapters.length; k++) {
                        let chapter = chapters[k],
                            include = false
                        let obj = {
                            propability: 0,
                            name: chapter,
                        }
                        let index = this.contains(chapter, this.chapters)
                        if(index >= 0) {
                            this.chapters[index].propability += 0.1
                        } else {
                            this.chapters.push(obj)
                        }
                    }

                    for(let m=0; m<topics.length; m++) {
                        let topic = topics[m],
                            obj = {
                                propability: 0.1,
                                name: topic,
                                chapter: "NONE"                                
                            }
                        let chap = this.findChapterOfTopic(topic, book)
                        if(chap !== -1) {
                            obj.chapter = chap
                        }
                        let index = this.contains(topic, this.topics)
                        if(index >= 0) {
                            if(this.topics[index].propability < 0.9) {
                                this.topics[index].propability += 0.1
                            }
                        } else if(this.topics.length < 20){
                            this.topics.push(obj)
                        }
                    }
                }
            }


            sections.A = sections.A.sort(this.dynamicSort("propability"))
            sections.B = sections.B.sort(this.dynamicSort("propability"))
            
            sections.A = this.removeDuplicates(sections.A, 'title')
            sections.B = this.removeDuplicates(sections.B, 'title')
            

            let j = 0, k = 0, papers = 5
            if(dataset.length < 5) {
                papers = dataset.length
            } 
            for(let i=0; i < papers; i++) {
                let sectionA = sections.A.slice(j, (j+13)),
                    sectionB = sections.B.slice(k, (k+3))

                j += 13
                k += 3
                this.past_papers.push({
                    A: sectionA,
                    B: sectionB
                })
            }

            this.generatePieChart(this.chapters)

        },
        generatePieChart(chapters) {
            let avg = 0
            for(let i=0; i<chapters.length; i++) {
                avg += chapters[i].propability
            }
            
            let gradient = "",
                totalPercent = 0

            for(let i=0; i<chapters.length; i++) {
                let percent = Math.round((chapters[i].propability / avg) * 100)
                totalPercent += percent
                gradient += this.colors[i] + " 0, "
                gradient += this.colors[i] + " " + totalPercent + '%,' 
                this.pie_chart_data.push({
                    percent: percent + '%',
                    color: this.colors[i],
                    chapter: chapters[i].name,
                    chapterNumber: parseInt(chapters[i].name.replace( /[^\d.]/g, '' ))
                })
            }
            this.activeChapterData =  this.pie_chart_data[0].chapterNumber
            
            this.gradient = `radial-gradient(circle closest-side, transparent 72%, white 0), conic-gradient(${gradient.slice(0, -1)})`

        },
        generatePaper() {
            this.loading = true
            this.firebase_get_one('books/' + this.class_ + '/' + this.course, (res) => {
                this.loading = false
                if(!res) {
                    let notification = {
                        title: 'Book not Found!',
                        description: 'The Book of class ' + this.class_ + 'th (' + this.course + ') cannot be found' 
                    }
                    this.alertnotification(notification, 'danger')                    
                    return
                } else {
                    let book = res
                    this.loading = true
                    this.firebase_get('pastpapers/' + this.class_ + '/' + this.course, (res) => {
                        this.loading = true
                        if(!res) {
                            let notification = {
                                title: 'Dataset not Found!',
                                description: 'The dataset of class ' + this.class_ + 'th (' + this.course + ') cannot be found' 
                            }
                            this.alertnotification(notification, 'danger')                    
                            return
                        } else {
                            let notification = {
                                title: 'Past Paper Generated',
                                description: 'We have generated ' + (res.length > 5 ? 5 : res.length) + ' past papapers for you. Their report is also been attached to it' 
                            }
                            this.alertnotification(notification, 'success')       
                            let dataset = res 
                            this.generateReport({ dataset, book })            
                        }
                    })
                }
            })
        },


    },
    mounted() {
        // let background = `radial-gradient(circle closest-side, transparent 72%, white 0), conic-gradient(
        //                         #4e79a7 0,
        //                         #4e79a7 30.3%,
        //                         #f28e2c 0,
        //                         #f28e2c 54.6%,
        //                         #e15759 0,
        //                         #e15759 72.8%,
        //                         #76b7b2 0,
        //                         #76b7b2 100%
        //                     )`

        // $('.pie-chart')[0].style.MozBackground = background;
        // $('.pie-chart')[0].style.WebkitBackground = background;
        // $('.pie-chart')[0].style.background = background;        

        // console.log($('.pie-chart')[0])
    }
}
</script>

<style>

</style>