<template>
  <div class="h-100 p-4">
        <div class="d-flex pb-2 justify-content-end align-items-center">
            <div class="p-2">
                <select style="width:250px" class="custom-select text-md bg-light bd-none pl-4 pr-4 bd-round box-shadow" v-model="course">
                    <option selected>Specify Course</option>
                    <option value="Computer Science">Computer Science</option>
                    <option value="Pakistan Studies">Pakistan Studies</option>
                </select>
            </div>
            <div class="p-2">
                <select style="width:250px" class="custom-select text-md bg-light bd-none pl-4 pr-4 bd-round box-shadow" v-model="class_">
                    <option selected>Specify Class</option>
                    <option value="9">9th Class</option>
                    <option value="10">10th Class</option>
                    <option value="11">1st Year</option>
                    <option value="12">2nd Year</option>
                </select>                                  
            </div>
        </div>      
      <div v-if="course && class_ && course != 'Specify Course' && class_ != 'Specify Class'" class="w-100 justify-content-center align-items-center bd-bottom pb-5 flex-wrap d-flex animate__animated  animate__zoomIn animate__faster">
          <button class="btn btn-block" style="font-size:5rem" @click="uploadBook()">
              <span class="mdi mdi-file-document-multiple text-orange"></span>
          </button>
          <div class="text-center">
            <p class="m-0 text-md font-gt-america">Upload Your Paper</p>
            <p class="small"><strong>Formats:</strong> <i>.pdf, .jpg, .png</i></p>
          </div>
      </div>
        <div v-if="chapters.length > 0 || topics.length > 0 || subtopics.length > 0" class="d-flex w-100 justify-content-around bd-bottom pb-5 pt-5 bg-light">
            <div>
                <h3 class="font-gt-america">Highlighted Chapters</h3>
                <div class="line"></div>
                <ul style="max-height:500px" class="overflow-auto">
                    <li class="text-sm text-capitalize hov p-1" v-for="(c, i) in chapters" :key="i">&#9755; {{ formatString(c) }}</li>
                </ul>
            </div>
            <div>
                <h3 class="font-gt-america">Highlighted Topics</h3>
                <div class="line"></div>
                <ul style="max-height:500px" class="overflow-auto">
                    <li class="text-sm text-capitalize hov p-1" v-for="(c, i) in topics" :key="i">&#9755; {{ formatString(c) }}</li>
                </ul>
            </div>
            <div>
                <h3 class="font-gt-america">Highlighted Subtopics</h3>
                <div class="line"></div>
                <ul style="max-height:500px" class="overflow-auto">
                    <li class="text-sm text-capitalize hov p-1" v-for="(c, i) in subtopics" :key="i">&#9755; {{  formatString(c) }}</li>
                </ul>
            </div>
        </div>
     

      <div>
          <div>
              <div class="p-5" v-if="questions.length < 1 && !loading">
                <h4 class="pb-2">Info</h4>
                <ul class="text-sm">
                    <li>Uploading a paper in pdf format will be directly processed and on the basis of that, pastpapers will be generated</li>
                    <li>If paper is been uploaded in .jpg (image) format, text will be first extracted from the paper and will be previewed and after 
                        that, paper will be generated.
                    </li>
                    <li>Text extracted from image will be highly depends upon the quality of the image.</li>
                </ul>
              </div>
            <div class="w-100 text-center mx-auto animate__animated animate__zoomIn animate__faster" v-if="loading">
                <div class="clearfix transition mx-auto text-center w-100 d-flex justify-content-center p-4">
                    <div class="c100 transition"
                        :class="['p' + parseInt(progress*100), 
                        parseInt(progress*100) > 75 ? 'green' : '', 
                        parseInt(progress*100) > 0 && parseInt(progress*100) < 25 ? 'orange' : '']">
                        <span>{{parseInt(progress*100)}}%</span>
                        <div class="slice">
                            <div class="bar"></div>
                            <div class="fill"></div>
                        </div>
                    </div>

                </div>                  

            </div>

              <!-- <p v-if="loading" class="text-center p-5">
                    <span class="spinner-border spinner-border-sm mb-2 text-orange"></span>   
                    <br> 
                  {{ parseInt(progress*100) }}% Processed
              </p> -->
              <div class="d-flex">
                <div v-for="(item, i) in questions" :key="i" class="bd-bottom p-5 w-50">
                    <h2 class="font-gt-america mb-4">Section {{ sections[i]}}</h2>
                    <div class="pl-4">
                        <div v-for="(q, j) in item" :key="j">
                                <div class="input-group w-100 bd-bottom hov m-0">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-none text-orange bd-round bd-none text-sm pt-0 pb-0 pr-0 font-weight-bold"><i>{{ j + 1 }}.</i> </span>
                                    </div>                                    
                                    <input v-if="q.title" type="text" class="bd-none text-sm form-control bg-none" v-model="q.title">
                                </div>
                        </div>
                    </div>
                </div>
              </div>

          </div>
      </div>
  </div>
</template>

<script src="https://mozilla.github.io/pdf.js/build/pdf.js"></script>
<script>
import $ from 'jquery'
import PDFJS from 'pdfjs-dist'
import Tesseract from 'tesseract.js';

export default {
    data() {
        return {
            progress: 0,
            sections: ["B", "C"],
            classes: [9, 10, 11, 12],
            section: [],
            questions: [],
            books: [],
            chapters: [],
            topics: [], subtopics: [],
            addingPaper: false,
            loading: false,
            course: "Specify Course",
            class_: "Specify Class"
        }
    },
    methods: {
        formatString(str) {
            return str.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '')
        },
        addBook() {
            this.addingPaper = true
            let obj = {
                course: this.course,
                class: this.classes[parseInt(this.class_)],
                sections: this.questions,
            }
            this.firebase_push_db({ ref: `pastpapers/${obj.class}/${obj.course}` , obj }, (res) => {
                this.alertmsg("Paper Added Successfully", "success")
                this.addingPaper = false
                setTimeout(() => {
                    location.reload()                
                }, 1000);
            })            
        },
        addNewSubtopic(i, j) {
            this.chapters[i].topics[j].subtopics.push("New Topic")
        },
        scanPaper({ q, book }) {
            for(let i=0; i<q.length; i++) {
                let section = q[i]
                for(let j=0; j<section.length; j++) {
                    let { topics, subtopics, chapters } = this.relateThisQ({ q: section[j].title.split(" "), chapters: book.chapters })
                    for(let k=0; k<topics.length; k++) {
                        let topic = topics[k]
                        if(!this.topics.includes(topic)) {
                            this.topics.push(topic)
                        }
                    }
                    for(let k=0; k<subtopics.length; k++) {
                        let subtopic = subtopics[k]
                        if(!this.subtopics.includes(subtopic)) {
                            this.subtopics.push(subtopic)
                        }
                    }
                    for(let k=0; k<chapters.length; k++) {
                        let chapter = chapters[k]
                        if(!this.chapters.includes(chapter)) {
                            this.chapters.push(chapter)
                        }
                    }   
                }
            }

            console.log({ topics: this.topics, subtopics: this.subtopics, chapters: this.chapters}, 'abcd...')
        },
        getBook() {
            this.firebase_get_one('books/' + this.class_ + '/' + this.course, (res) => {
                this.subtopics = []
                this.chapters = [] 
                this.topics = []
                this.scanPaper({ q: this.questions, book: res })                  
            })
        },
        processImg(e) {
            this.handleImage(e, (canvas) => {
                this.loading = true
                Tesseract.recognize(
                    canvas,
                    'eng',
                    { logger: m => {
                        this.progress = m.progress
                    } })
                    .then(({ data: { text } }) => {
                        console.log(text.toLowerCase(), this.course, 'mytext')
                        this.section = this.getSectionImg(text)

                        if(!this.section) {
                            let notification = {
                                title: 'Invalid Image',
                                description: `The image maybe invalid or does not contain any data for parsing. Try uploading different image
                                    <br>
                                    <strong>Identified Text:</strong> ${text}
                                    `
                            }
                            this.alertnotification(notification, 'danger')                            
                        }
                        else if (( (text.toLowerCase().includes("pakistan") || text.toLowerCase().includes("pakistan studies")) 
                                && (this.course.toLowerCase() == "computer science") ) 
                                ||
                                (text.toLowerCase().includes("computer") && (this.course.toLowerCase() == "pakistan studies"))
                                ) {
                            let notification = {
                                title: 'Invalid Subject',
                                description: `It looks like, you have uploaded an invalid paper. Please try to upload a valid paper.`
                            }
                            this.alertnotification(notification, 'danger')                            
                        }
                        else if(this.section.length > 1) {
                            this.questions = []
                            for(let i=0; i<this.section.length; i++) {
                                this.questions.push([])
                                for(let j=0; j<this.section[i].length; j++) {
                                    if( this.section[i][j].includes("note:") || 
                                        this.section[i][j].includes("attempt any") || 
                                        this.section[i][j].includes("answer any") ||  
                                        this.section[i][j].includes("seven parts") || 
                                        this.section[i][j].includes("carry equal marks") || 
                                        this.section[i][j].includes("briefly answer") || 
                                        this.section[i][j].length < 15) {
                                            continue
                                    }
                                    console.log(this.sections[i][j], 'sectio[ik')
                                    this.questions[i].push({
                                        title: this.section[i][j]
                                    })
                                }
                            }
                            this.getBook()
                            this.loading = false
                        }
                        else {
                            let notification = {
                                title: 'Invalid Image',
                                description: 'The image maybe invalid or does not contain any data for parsing. Try uploading different image'
                            }
                            this.alertnotification(notification, 'danger')                            
                        }
                    })
            })
        },
        uploadBook() {
            let upload = this.uploadfile("*")
            let $this = this
            upload.change((e) => {
                let type = this.filetype(e)
                if(type == "image/jpeg" || type == "image/png") {
                    this.alertmsg("You have uploaded Image", "info")
                    this.processImg(e)
                    return
                }
                this.pdfToTxt(e, (text) => {
                    this.section = this.getSection(text)
                    if(this.section !== -1 && this.section.length == 2) {
                        for(let i=0; i<this.section.length; i++) {
                            this.questions.push(
                                this.getQuestions(this.section[i])
                            )
                        }
                        console.log(this.questions, 'questions')
                    } 
                    else {
                        this.alertmsg("Some Unusual Behaviour Occur", "danger")
                    }


                })
            })
        },        
    },
    mounted() {
        // this.questions = [
        //     [{ title: "() compare tstand 3rd generation computers."}, 
        //     { title: "(i) briefy describe napier's bone."}, 
        //     { title: "(i) give any three objectives of operating system."}, 
        //     { title: "(v) whatis meant by managing data and why s it important?"}, 
        //     { title: "name any three areas of application of ms excel."}, 
        //     { title: "7 (vi) why are header and footer important in a word document?"}, 
        //     { title: ": (viiiy  differentiate attenuation and distortion:"}, 
        //     { title: "i (x)  whatis bandwidth?"}, 
        //     { title: "i () whatis meant by data transmission?"}, 
        //     { title: ": (x)  differentiate between a server and a ciient computer."}, 
        //     { title: "b (xii) ~ differentiate authentication and authorization."}, 
        //     { title: "il (xii)  whatis meant by information privacy?"}, 
        //     { title: " briefly describe time sharing operating system."} ],
            
        //     [{ title: "q.3 a - explain four types of application software. (©4)"}, 
        //     { title: "b.  write a note on dial-up and dsl intemet connection. i (04)"}, 
        //     { title: "- q.4 a . explain asynchronous and synchronous data iransmission modes with example (06)"}, 
        //     { title: "explainuse of access card. © i (02)"}, 
        //     { title: "g q.5 explain in detall types of network based on geographical area. (08)"} ],
        // ]
        // this.getBook()
    }
}
</script>

<style>

</style>