import Vue from 'vue'
const path = require('path')
const moment = require('moment')
const mimetype = ["image/jepg", "image/png", "image/jpg", "image/svg+xml"]
import $ from 'jquery'
import PDFJS from 'pdfjs-dist'
Vue.mixin({
    methods:{
        dropdown(list, e) {
            let container = $("<div>"),
                timeout = null,
                buttons = []
            container.addClass("bg-white box-shadow pt-2 pb-2 animate__animated  animate__fadeIn animate__faster bd-radius-5")
            container.css({
                width: "200px",
                position:"absolute",
                left: "0px",
                top: "0px",
                zIndex: 10000
            })
            for(let i=0; i<list.length; i++) {
                let button = $("<a>"),
                    href = null
        
                button.addClass("btn text-sm bg-white btn-hov d-flex align-items-center text-left pl-3 pr-2 mt-0 btn-block animate__animated  animate__fadeInUp animate__faster")
        
                button.attr("href", 'javascript:void(0)')
                button.html('<span class="mr-2 mdi mdi-24px '+list[i].icon+'"></span>' + list[i].title)
                container.append(button)
                buttons.push(button)
            }
            container.mouseleave(() => {
                timeout = setTimeout(() => {
                    container.remove()
                }, 500);
            })
            container.mouseenter(() => clearTimeout(timeout))
            $(window).click((e) => {
                if(e.target.parentNode != container[0] && !$(e.target).hasClass('dropdown-btn') && e.target !== container[0]) {
                    container.remove()
                }
            })
        
            $(window).resize(() => container.remove())
            let top = $(e.currentTarget).offset().top,
                left = $(e.currentTarget).offset().left,
                w = $(window).width(),
                h = $(window).height(),
                w_ = $(container).width(),
                h_ = $(container).height()
        
            if(top+h_ > h) {
                container.css({
                    top: (h - h_ - 10) + 'px'
                })
            } else {
                container.css({
                    top: (top + 10) + 'px'
                })
            }
            if(left+w_ > w) {
                container.css({
                    left: (w - w_ - 10) + 'px'
                })
            } else {
                container.css({
                    left: (left) + 'px'
                })
            }
        
            $("body").append(container)
        
            return buttons
        },
        setCookie(name,value,days) {
            value = JSON.stringify(value)
            var expires = "";
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days*24*60*60*1000));
                expires = "; expires=" + date.toUTCString();
            }
            document.cookie = name + "=" + (value || "")  + expires + "; path=/";
        },
        getCookie(name) {
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for(var i=0;i < ca.length;i++) {
                var c = ca[i];
                while (c.charAt(0)==' ') c = c.substring(1,c.length);
                if (c.indexOf(nameEQ) == 0) return JSON.parse(c.substring(nameEQ.length,c.length));
            }
            return null;
        },
        eraseCookie(name) {   
            document.cookie = name+'=; Max-Age=-99999999;';  
        },
        mydate() {
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            var yyyy = today.getFullYear();
            
            today = mm + '/' + dd + '/' + yyyy;
            return today
        },     
        
        format_url(str) {
            if(str.split(" ").length > 1) {
                return str.split(" ").join("-").toLowerCase()
            } else {
                return str.toLowerCase()
            }
        },
        format_sw(sw) {
            sw.path = JSON.parse(sw.path)
            console.log(sw.path, 'path')
            let file_type = sw.path[0].mimetype,
                thumbnail = mimetype.includes(file_type) ? sw.path[0].filename : sw.path[1].filename,
                file = !mimetype.includes(file_type) ? sw.path[0].filename : sw.path[1].filename,
                now = this.date(),
                created = JSON.parse(sw.date),
                start = moment([created.year, created.month, created.day]),
                end = moment([now.year, now.month, now.day]),
                date = start.from(end),
                title = sw.title,
                description = sw.description,
                download = sw.download,
                id = sw.id
            
            return {
                id, date, title, description, thumbnail, file, download
            }
        },
        date_moment(date) {
            let now = this.date(),
                created = JSON.parse(date),
                start = moment([created.year, created.month, created.day]),
                end = moment([now.year, now.month, now.day])
            return start.from(end)
        },
        date() {
            var dateObj = new Date();
            var month = dateObj.getUTCMonth() + 1; //months from 1-12
            var day = dateObj.getUTCDate();
            var year = dateObj.getUTCFullYear();
            return {
                year, month, day
            }
        },
        alertmsg(msg, color="primary") {
            let button = $("<button>")
        
            button.addClass('btn bg-dark-2 bd-round box-shadow pl-4 pr-4 pt-2 pb-2 text-sm animate__animated  animate__fadeInUp animate__faster d-flex align-items-center')
            button.css({
                position: "fixed",
                bottom: "25px", left: "25px"
            })
            button.html(`<span class='material-icons mr-2 text-${color}'>info</span><span class="text-${color}">${msg}</span>`)
            $("body").append(button)
        
            setTimeout(() => {
                button.removeClass("animate__fadeInUp").addClass("animate__zoomOut")
                setTimeout(() => {
                    button.remove()            
                }, 500);
            }, 2000);
        },
        filetype(e) {
            return e.target.files[0].type
        },
        handleImage(e, callback){
            var reader = new FileReader();
            reader.onload = function(event){
                var img = new Image();
                img.onload = function(){
                    let canvas = document.createElement("canvas"),
                        ctx = canvas.getContext("2d")
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img,0,0);
                    callback(canvas)
                }
                img.src = event.target.result;
            }
            reader.readAsDataURL(e.target.files[0]);     
        },        
        uploadfile(accept = "application/pdf") {
            var input=document.createElement('input');
            input.type="file";
            document.body.append(input)
            $(input).addClass("d-none")
            $(input).attr("accept", accept)
            setTimeout(function() {
                $(input).click();
            }, 100);
            return $(input)
        },
        async getText(typedarray) {

            //PDFJS should be able to read this typedarray content
            const PDFJS = await import('pdfjs-dist/build/pdf');
            const pdfjsWorker = await import('pdfjs-dist/build/pdf.worker.entry');
          
            PDFJS.GlobalWorkerOptions.workerSrc = pdfjsWorker;
            var pdf = PDFJS.getDocument(typedarray);
            return pdf.promise.then(function (pdf) {
                // get all pages text
                var maxPages = pdf._pdfInfo.numPages;
                var countPromises = [];
                // collecting all page promises
                for (var j = 1; j <= maxPages; j++) {
                    var page = pdf.getPage(j);
                    var txt = "";
                    countPromises.push(page.then(function (page) {
                        // add page promise
                        var textContent = page.getTextContent();

                        return textContent.then(function (text) {
                            // return content promise
                            return text.items.map(function (s) {
                                return s.str;
                            }).join(''); // value page text
                        });
                    }));
                }

                // Wait for all pages and join text
                return Promise.all(countPromises).then(function (texts) {
                    return texts.join('');
                });
            });
        },        
        pdfToTxt(e, callback) {
            var $this = this
            var file = $(e.target).prop("files")[0]                
            var fileReader = new FileReader();
             fileReader.onload = function () {
                console.log(this.result)
                var typedarray = new Uint8Array(this.result);
                //calling function to read from pdf file
                $this.getText(typedarray).then(function (text) {
                    callback(text)
                }, 
                function (reason) //Execute only when there is some error while reading pdf file
                {
                    alert('Seems this file is broken, please upload another file');
                    console.error(reason);
                });                      
            }
            fileReader.readAsArrayBuffer(file);
        },
        getChapters(courseContent) {
            let lowercase = courseContent.toLowerCase(),
                maxChapters = 100, cursor = 0, chapters = []
            

            for(let i=1; i<maxChapters; i++) {
                let chapter_end = lowercase.indexOf("chapter " + (i + 1)),
                    chapter_name = lowercase.split("chapter " + i)[1].split(i + ".1 ")[0].trim()
                    
                chapters.push({
                    chapter: i,
                    // content: courseContent.substr(cursor, chapter_end),
                    name: chapter_name,
                    content: lowercase.split(chapter_name)[1].split("chapter " + (i+1))[0]
                })

                if(chapter_end == -1 || chapter_end == 0) {
                    return chapters
                }
                cursor = chapter_end
            }
            return chapters            
        },
        getTopics(c) {
            let { chapter, content } = c

            let topics = []

            let maxTopics = 100, cursor = 0
            for(let i=1; i<maxTopics; i++) {
                let topic_end = content.indexOf(" " + chapter + "." + (i + 1) + " "),
                    topic = content.substring(cursor, topic_end == -1 ? 10000 : topic_end),
                    topic_name = topic.split(chapter + "." + i + ".1")           
                cursor = topic_end

                topics.push({
                    show: true,
                    name: topic_name[0],
                    subtopics: topic_name[1] ? topic_name[1].split(" " + chapter + "." + i) : []
                })

                if(topic_end == -1) {
                    return topics
                }
            }  
            console.log('-------------------------------------------------')
        },
        getSectionImg(paper) {
            let lowercase = paper.toLowerCase()
            let sectionB = lowercase.split(" q. 2 "),
                sectionC = null
            let split = " q.3 "
            if(sectionB.length == 1) {
                sectionB = lowercase.split("q.2")
                if(sectionB.length == 1) {
                    sectionB = lowercase.split("q2")
                }
                if(sectionB.length == 1) {
                    sectionB = lowercase.split("q 2")
                }
            }
            console.log(sectionB[1], sectionB, 'section')
            if(sectionB.length > 1) {
                return this.mysections(sectionB[1].split("\n"))

            } else {
                return false
            }
        },
        getSection(paper) {            
            let lowercase = paper.toLowerCase()

            let sectionB = lowercase.split("section c"),
                sectionC = null
            if(sectionB.length == 2) {
                sectionC = sectionB[1]
                sectionB = sectionB[0].split("section b")
                if(sectionB.length == 2) {
                    sectionB = sectionB[1]
                    return [ sectionB, sectionC ]
                }
                else {
                    this.alertmsg("Error Parsing Section B From Paper", "danger")
                    return -1

                }
            }
            else {
                this.alertmsg("Error Parsing Sections From Paper", "danger")
                return -1 
            }
        },
        mysections(q) {
            for(let i=0; i<q.length; i++) {
                if(i > 0) {
                    if(q[i].includes("attempt any") || 
                        q[i].includes("q.3") || 
                        q[i].includes("q. 3") || 
                        q[i].includes("section - c") ||
                        q[i].includes("section ~ c")) {
                        let sectionA = q.slice(0, i - 1),
                            sectionB = q.slice(i, 10000)
                            return [sectionA, sectionB]
                    }
                }
            }
            return -1
        },
        getQuestions(section) {
            let maxQ = 100, cursor = 0, questions = []
            for(let j=1; j<=maxQ; j++) {
                // let Qend = section.indexOf(" " + (j+1) + ". ")
                let Qend = section.indexOf(" " + (j+1) + ". ")
                if(Qend == -1) {
                    Qend = section.indexOf(" " + (j+1) + "- ")
                }
                let q = section.substring(cursor, Qend == -1 ? 10000 : Qend)
                questions.push({ title: q, parts: false, list: [],  weight: 10 })
                cursor = Qend

                if(Qend == -1 ) {
                    return questions
                }
            }
        },
        alertnotification(data, color='primary') {
            let container = $("<div>"),
                card = $("<div>"),
                title = $("<h4>"),
                description = $("<p>"),
                close_container = $('<div>'),
                close = $('<button>')
        
            container.addClass("position-fixed bg-overlay d-flex align-items-center justify-content-center animate__animated  animate__fadeIn animate__faster ")
            container.css({
                top: '0px', left: '0px', width: '100%', height: '100%', zIndex: '100000000'
            })
        
            card.css({
                width: '550px', height: 'auto'
            })
            card.addClass("bg-white  animate__animated  animate__zoomIn animate__faster box-shadow")
            description.addClass('text-dark p-4')
            title.addClass('bg-'+color+' text-white w-100 p-4 font-weight-normal box-shadow')
            title.html(data.title)
            description.html('<span class="mdi mdi-36px mdi-information-variant text-'+color+' p-0"></span> <br>' + data.description)
            card.append(title)
            card.append(description)
        
            close.html('Done')
            close.addClass('btn text-'+color+' pl-4 pr-4 mb-2 mr-2 bd-round')
            close_container.addClass('w-100 text-right p-2 mr-4')
            close_container.append(close)
            card.append(close_container)
            container.append(card)
            $('body').append(container)
        
            close.click(() => container.remove())
        
        },        
        shuffle(array) {
            var currentIndex = array.length, temporaryValue, randomIndex;
          
            // While there remain elements to shuffle...
            while (0 !== currentIndex) {
          
              // Pick a remaining element...
              randomIndex = Math.floor(Math.random() * currentIndex);
              currentIndex -= 1;
          
              // And swap it with the current element.
              temporaryValue = array[currentIndex];
              array[currentIndex] = array[randomIndex];
              array[randomIndex] = temporaryValue;
            }
          
            return array;
        },        
        dynamicSort(property) {
            var sortOrder = 1;
            if(property[0] === "-") {
                sortOrder = -1;
                property = property.substr(1);
            }
            return function (a,b) {
                /* next line works with strings and numbers, 
                 * and you may want to customize it to your needs
                 */
                var result = (a[property] > b[property]) ? -1 : (a[property] < b[property]) ? 1 : 0;
                return result * sortOrder;
            }
        },    
        removeDuplicates(originalArray, prop) {
            var newArray = [];
            var lookupObject  = {};
       
            for(var i in originalArray) {
               lookupObject[originalArray[i][prop]] = originalArray[i];
            }
       
            for(i in lookupObject) {
                newArray.push(lookupObject[i]);
            }
             return newArray;
        },              

        relateThisQ({ q, chapters }) {
            let _chap = { p: 0, $: [] },
                _topics = { p: 0, $: [] },
                _subtopics = { p: 0, $: [] },
                conjunctions = ["for", "and", "on", "the", "yet", "so", "but", "of", "nor", "before", "since", "until", "when", "that", "in", "with", "its", "it", "this", "data", "types", "between", "simple", "three", "type"]
            for(let i=0; i<q.length; i++) {
                let Qword = q[i]
                for(let j=0; j<chapters.length; j++) {
                    let chapter = chapters[j].name,
                        chapter_no = chapters[j].chapter,
                        topics = chapters[j].topics
                    
                    // if(chapter.includes(Qword)) {
                    //     _chap.p += 0.05
                    //     _chap.$.push(chapter)
                    // }                

                    if(!topics) {
                        continue
                    }
                    for(let k=0; k<topics.length; k++) {
                        let topic = topics[k].name,
                            subtopics = topics[k].subtopics

                        // if(topic.includes(Qword)) {
                        //     _topics.p += 0.05
                        //     _topics.$.push(topic)                            
                        // }
                        if(!subtopics) {
                            continue
                        }
                        for(let y=0; y<subtopics.length; y++) {
                            let subtopic = subtopics[y]

                            if(subtopic.includes(Qword) && !conjunctions.includes(Qword.trim()) && Qword.length > 3) {
                                _subtopics.p += 0.05
                                !_subtopics.$.includes(subtopic) ? _subtopics.$.push(subtopic) : ''                                
                                !_chap.$.includes(chapter) ? _chap.$.push('Chapter #' + chapter_no + ' - ' + chapter) : ''
                                !_topics.$.includes(topic) ? _topics.$.push(topic) : ''    
                                if(_subtopics.p > 1) {
                                        _subtopics.p = 1                                        
                                }
    
                            }
                        }                  

                    }
                }
            }
            return {
                chapters: _chap.$,
                subtopics: _subtopics.$,
                topics: _topics.$,
                propability: _subtopics.p
            }
        }
    }
})